import React from 'react';

export default FirebaseKeys = {
 	 apiKey: "AIzaSyCb_nvKPCsu7fnPJVWHzW3dx4AEpuGgspE",
    authDomain: "thesarathi-9e35e.firebaseapp.com",
    databaseURL: "https://thesarathi-9e35e.firebaseio.com",
    projectId: "thesarathi-9e35e",
    storageBucket: "thesarathi-9e35e.appspot.com",
    messagingSenderId: "303537616637",
    appId: "1:303537616637:web:244490082ab8d76bfaf094",
    measurementId: "G-XV4MD8H74R"
  };