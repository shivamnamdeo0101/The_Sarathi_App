import React from 'react';
import { StyleSheet,Text, View ,TouchableOpacity,Image,StatusBar,LayoutAnimation,Alert,ImageBackground} from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import * as Google from 'expo-google-app-auth';
import Fire from "../Fire";

export default class RegisterScreen extends React.Component {

  //Remove Unwanted Header
  static navigationOptions = {
    headerShown:false
  };

  constructor(props) {
    super(props)
    this.state={
      user:null
    }
  }

  handleSignup = () =>{
    Fire.shared.createUser(this.state.user);
  };

  signInWithGoogleAsync= async () => {
      try {
        const { type, user } = await Google.logInAsync({
            behaviour: 'web',
            expoClientId:"303537616637-9phi8msq16mccghmfl0j678ftjf924k1.apps.googleusercontent.com",
          androidStandaloneAppClientId:'303537616637-m0ulijq4jefn8al9s2ugal1jiq1cn396.apps.googleusercontent.comm',
          androidClientId: '303537616637-m0ulijq4jefn8al9s2ugal1jiq1cn396.apps.googleusercontent.com',
          scopes: ['profile', 'email'],
        })
        if (type === 'success') {
          this.setState({ 
            user 
          });
          this.handleSignup()
          }
          console.log(user.name);
          console.log(user.photoUrl);
          console.log(user.email);
      } catch ({ message }) {
        alert('login: Error:' + message);
    }
  }
  
  render(){

    LayoutAnimation.easeInEaseOut();
    return(

      <ImageBackground source={require("../assets/bg.jpg")} style={{width:"100%",height:"100%"}}>
      <View style={styles.container }>
         
         {/*Status Bar Light Content Color */}
          <StatusBar barStyle="light-content"></StatusBar>

          <View style={{flexDirection:"column",justifyContent:"space-evenly",marginTop:50}}>
            <Text style={styles.greeting}>Hello</Text>
            <Text style={styles.greeting}>There<Text style={{color:"#348ceb",fontSize:100}}>.</Text></Text>      
          </View>
        

          
      
        {/**  Login Form*/}

      <View style={styles.form}>           

        {/*Social Login*/}
        <Text style={{color:"#414959",fontSize:25,alignSelf:"center",fontWeight:"bold"}} >{`\n`}SIGN UP</Text>
        <View style={{flexDirection:"row",alignSelf:"center",justifyContent:"space-evenly"}}>
        
        <TouchableOpacity style={styles.social} onPress={() =>this.signInWithGoogleAsync()}>
        <Text style={{color:"#fff",fontSize:18}}>Sign Up Using Google</Text>
    
           <AntDesign name="google" size={24} color="#fff" />
        </TouchableOpacity>
     
        
        </View>
        

        {/**  Error Message*/}
        <View style={styles.errorMessage}> 
             {
              this.state.errorMessage &&
               <Text style={styles.error}>
                 {this.state.errorMessage}
               </Text>
             }
        </View>

          {/*Signup Login Switch*/}
        <TouchableOpacity style={{alignSelf:"center",marginTop:10}}
           onPress={()=>
            this.props.navigation.navigate("Login")
          }
        >
          <Text style={{color:"#414959",fontSize:18,marginBottom:15}}>
            Already have Account ? <Text style={{fontWeight:"bold",color:"#1a95e8"}}>Sign In</Text>
          </Text>
        </TouchableOpacity>




         {/**  Login Form*/}

      </View>

      </View>
             </ImageBackground>
    );
  }
}


const styles = StyleSheet.create({
  container:{
    flex:1,
  },
  greeting:{
    marginBottom:-40,
    color:"#444",   
    fontSize:80,
    fontWeight:"bold",
    textAlign:"left",
    marginLeft:40,
   
  },
  line:{
    color:"#444449",
    fontSize:10,
    fontWeight:"bold",
    marginLeft:40,
    width:100
  },
  error:{
    color:"#f74343",
    fontSize:13,
    fontWeight:"600",
    textAlign:"center",

  },
  errorMessage:{
    alignItems:"center",
    justifyContent:"center",
    marginTop:8
  },
  form:{
    marginHorizontal:20,
    backgroundColor:"#f0f3f5",
    padding:10,
    borderRadius:30,
    marginTop:100,
    shadowColor: "#404",
    shadowOffset: {
      width: 1000,
    height: 120,
    },
    shadowOpacity:100,
    shadowRadius: 100,
    elevation: 50, 
  },

  social:{
    marginTop:15,
    width:220,
    height:50,
    borderRadius:16,
    backgroundColor:"#348ceb",
    alignItems:"center",
    justifyContent:"center",
    padding:20,
    flexDirection:"row",
    justifyContent:"space-around",
    shadowColor: "#404",
    shadowOffset: {
      width: 1000,
    height: 120,
    },
    shadowOpacity:100,
    shadowRadius: 100,
    elevation: 5, 
  },

})
