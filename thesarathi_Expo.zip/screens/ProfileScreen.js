import React from 'react'
import { View, Text, StyleSheet, TouchableOpacity, LayoutAnimation,Image ,ImageBackground,ScrollView} from 'react-native';
import Fire from "../Fire";
import firebase from "firebase";

export default class ProfileScreen extends React.Component {


  //Navigation False
    static navigationOptions = {
        headerShown: false,
    };
    
    state = {
        user:{}
    };


    //Fetch User Details
    componentDidMount() {
        const user  = this.props.uid || Fire.shared.uid;

        Fire.shared.firestore
        .collection("users")
        .doc(user)
        .onSnapshot(doc=>{
            this.setState({user:doc.data()});
        });

    };

    componentWillUnmount(){
      
    }

    // Signing Out User
    signOutUser = () => {
        firebase.auth().signOut();
    };
    
    render() {
        LayoutAnimation.easeInEaseOut();
        return (

            //Background Image
            <ImageBackground source={require("../assets/bg.jpg")} style={{width:"100%",height:"100%"}}>
             
            {/* Profile Container*/ }
            <View style={styles.container}>
        
                <View style={styles.avatarContainer}>
                    <Image style={styles.avatar} source={this.state.user.avatar ? { uri: this.state.user.avatar } : require("../assets/page/user.png")}/>
                   

                 
                   <TouchableOpacity style={{alignSelf:"center"},styles.edit} onPress={() => this.props.navigation.navigate("EditProfile")}>
                      <Text style={{color:"#f0f3f5",fontSize:18}}>Edit</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={{alignSelf:"center"},styles.logout} onPress={this.signOutUser}>
                      <Text style={{color:"#f0f3f5",fontSize:18}}>Logout</Text>
                    </TouchableOpacity>
                  
            
                    
                   

                    
                </View>
                
                <ScrollView showsVerticalScrollIndicator={false}>

                      <View style={styles.textContainer}>
                       <Text style={styles.heading}>Name</Text>
                       <Text style={styles.text}>{this.state.user.name}</Text>

                     </View>

                     <View style={styles.textContainer}>
                       <Text  style={styles.heading}>Email</Text>
                       <Text style={styles.text}>{this.state.user.email}</Text>
                     </View>




                  {

                   (this.state.user.Qualification == "School") ?


                   <View style={styles.layout}>
                
                     <View style={styles.textContainer}>
                      <Text  style={styles.heading}>Education</Text>

                      <View style={styles.textContainer}>
                       <Text  style={styles.heading}>School Name</Text>
                       <Text style={styles.text}>{this.state.user.SchoolName}</Text>
                     </View>


                     
                      <View style={styles.textContainer}>
                       <Text  style={styles.heading}>State</Text>
                       <Text style={styles.text}>{this.state.user.State}</Text>
                     </View>

                     <View style={styles.textContainer}>
                       <Text  style={styles.heading}>Board</Text>
                       <Text style={styles.text}>{this.state.user.Board}</Text>
                     </View>

                     <View style={styles.textContainer}>
                       <Text  style={styles.heading}>Class</Text>
                       <Text style={styles.text}>{this.state.user.Class}</Text>
                     </View>


                     {/*  Users Class For > Than 10 */
                       (this.state.user.Class > 10) ?
                        <View style={styles.textContainer}>
                             <Text  style={styles.heading}>Subject</Text>
                             <Text style={styles.text}>{this.state.user.Subject}</Text>
                        </View>

                     :

                        <View>
                        </View>

                      /*  Users Class For > Than 10 */
                     }

                     {
                        (this.state.user.Drop == "Yes") ?


                      <View>
                         <View style={styles.textContainer}>
                          <Text  style={styles.heading}>Drop</Text>
                          <Text style={styles.text}>{this.state.user.Drop}</Text>
                        </View>

                          <View style={styles.textContainer}>
                            <Text  style={styles.heading}>Exams</Text>
                            <Text style={styles.text}>{this.state.user.Exams}</Text>
                          </View>

                        </View>

                      :

                        <View>
                        </View>
                     }


                      {/************************* */}
                     </View>         
                </View>


                   :
                    <View style={styles.layout}>
                
                     <View style={styles.textContainer}>
                      <Text  style={styles.heading}>Education</Text>

                      <View style={styles.textContainer}>
                       <Text  style={styles.heading}>College Name</Text>
                       <Text style={styles.text}>{this.state.user.CollegeName}</Text>
                     </View>

                      <View style={styles.textContainer}>
                       <Text  style={styles.heading}>Location</Text>
                       <Text style={styles.text}>{this.state.user.CollegeLocation}</Text>
                     </View>

                     

                     <View style={styles.textContainer}>
                       <Text  style={styles.heading}>Current Year</Text>
                       <Text style={styles.text}>{this.state.user.CurrentYear}</Text>
                     </View>

                     <View style={styles.textContainer}>
                       <Text  style={styles.heading}>Category</Text>
                       <Text style={styles.text}>{this.state.user.Category}</Text>
                     </View>

                    {
                      (this.state.user.Category == "Under Graduation") ?
                        
                      <View>
                        <View style={styles.textContainer}>
                            <Text  style={styles.heading}>Course</Text>
                            <Text style={styles.text}>{this.state.user.UGDegree}</Text>
                          </View>


                          {
                             (this.state.user.UGDegree == 'Bachelor of Engg./Tech') ?
                               <View style={styles.textContainer}>
                                <Text  style={styles.heading}>Course</Text>
                                <Text style={styles.text}>{this.state.user.Branch}</Text>
                               </View>
                             :
                              <View>
                                </View>
                          }
                        </View>
                          
                          
                        
                        
                        :
                      <View>
                        </View>

                    }

{
                      (this.state.user.Category == "Post Graduation") ?
                        
                 
                        <View style={styles.textContainer}>
                            <Text  style={styles.heading}>Course</Text>
                            <Text style={styles.text}>{this.state.user.PGDegree}</Text>
                          </View>

               

                        :
                      <View>
                      </View>

                    }
                   {/************************* */}
                     </View>  

                          
                </View>
                   }
                      <View style={styles.layout,{marginBottom:20}}>
                        <View style={styles.textContainer}>
                           <Text  style={styles.heading}>Interest</Text>
                            <Text style={styles.text}>Coding,Management,Web Development,React</Text>
                        </View>
                     </View>  
                    

                </ScrollView>
               
            </View>
            
            
            </ImageBackground>
        )
    }
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignContent:"flex-start",
        marginTop:6,
        padding:4
    },
    logout:{
        width:80,
        height:40,
        borderRadius:16,
        backgroundColor:"#ff5f03",
        alignItems:"center",
        justifyContent:"center",
        padding:5,
        shadowColor: "#f03",
        shadowOffset: {
          width: 100,
        height: 100,
        },
        shadowOpacity:10,
        shadowRadius: 10,
        elevation: 40, 
        
    },
    edit:{
      width:80,
      height:40,
      borderRadius:16,
      backgroundColor:"#5a89fa",
      alignItems:"center",
      justifyContent:"center",
      padding:5,
      shadowColor: "#f03",
      shadowOffset: {
        width: 100,
      height: 100,
      },
      shadowOpacity:10,
      shadowRadius: 10,
      elevation: 40, 
      
  },
  avatarContainer:{
    flexDirection:"row",
    justifyContent:"space-evenly"
  }  
,
 avatar:{
   width:100,
   height:100,
   borderRadius:50,
   borderWidth:5,
   borderColor:"#f0f3f5",   
 },
 text:{
  fontSize:17,
  color:"#444449"
 },
 textContainer:{
  padding:8,
  borderRadius:10,
  borderColor:"#ccc",
  borderWidth:2,
  marginTop:2,
  backgroundColor:"#fff",


 },
 heading:{
   fontSize:18,
   fontWeight:"bold",
   color:"#444",
   marginBottom:8,
 },
 layout:{
   marginTop:20,
   borderRadius:10,
  backgroundColor:"#fff",

 }

   
})