import React from 'react';
import { Ionicons,AntDesign } from "@expo/vector-icons";
import SearchableDropdown from "react-native-searchable-dropdown";
import {
    StyleSheet,
    Text,
    StatusBar,
    KeyboardAvoidingView,
    Alert,  
    View,
    Platform,
    TouchableWithoutFeedback
  } from "react-native";
import Fire from "../Fire";



export default class InterestScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
        expanded: false,
        overflowed: false,
        selectedTags: [],
        tags: [
        { id: 1, name: 'Management', },
        { id: 2, name: 'Bussiness Strategy', },
        { id: 3, name: 'Account Management', },
        { id: 4, name: 'Graphic Design', },
        { id: 5, name: 'Digital Marketing', },
        { id: 6, name: 'Web Development', },
        { id: 7, name: 'App Development', },
        { id: 8, name: 'Event Planning', },
        { id: 9, name: 'Engineering' },
        { id: 10, name: 'Entrepreneurship' },
        { id: 11, name: 'E-commerce' },
        { id: 12, name: 'Coding' },
        { id: 13, name: 'Producat Development' },
        { id: 14, name: 'Editing' },
        { id: 15, name: 'Real Estate' },
        { id: 16, name: 'Finance' },
        { id: 17, name: 'Government' },
        { id: 18, name: 'Higher Education' },
      ]
    }
  }

  SearchFilterFunction(text) {
    //passing the inserted text in textinput
    const newData = this.state.tags.filter((item)=> {return item==text});
    console.log(newData)
    this.setState({data: newData,text: text,});
  }



  UpdateInterest() {
    const user  = this.props.uid || Fire.shared.uid;

    Fire.shared.firestore
    .collection("users")
    .doc(user)
    .set({
        Interest: this.state.selectedTags,

    }, { merge: true })
        .then(mydata=>{
          Alert.alert("All Done")
          this.props.navigation.navigate("Profile")
        })
        this.setState({
          selectedTags:""
          })
  }




render() {  
    const { navigation } = this.props;
    return(
   <View style={styles.container}>

      <View style={styles.header}>
       <View>
         <AntDesign onPress={() => {navigation.goBack()}} name="leftcircleo" size={30} color="#444" style={{paddingTop:6,paddingRight:30}}/>
       </View>
       <Text style={{fontSize:20,padding:5,paddingRight:10,color:"#444"}}>Add Your Interest</Text>
       <Ionicons onPress={() => this.UpdateInterest()} name="md-done-all" size={30} color="#444" style={{paddingTop:6,paddingLeft:20}}/>

     </View>






    <StatusBar barStyle="light-content"></StatusBar>


    <TouchableWithoutFeedback>
    <View>
    <KeyboardAvoidingView behavior={Platform.OS == "android" ? "padding" : "height"} >
        <SearchableDropdown


          onTextChange={text => this.SearchFilterFunction(text)}
          multi={true}
          selectedItems={this.state.selectedTags}
          onItemSelect={(item) => {
              // console.log(item)
          const items = this.state.selectedTags;
          items.push(item)
          this.setState({ selectedTags: items });
          console.log(this.state.selectedTags)
          }}


          containerStyle={{ padding: 2,paddingTop:"5%"}}
          onRemoveItem={(item, index) => {
          const items = this.state.selectedTags.filter((sitem) => sitem.id !== item.id);
          this.setState({ selectedTags: items });
          console.log(this.state.selectedTags)
          }}
          itemStyle={{
              padding: 14,
              marginTop: 2,
              backgroundColor: '#f0f3f5',
              borderColor: '#f0f3f5',
              borderWidth: 2,
              borderRadius: 5,
            }}
            itemTextStyle={{ color: '#000',fontSize:15 }}
            itemsContainerStyle={{ maxHeight:"100%" }}
            items={this.state.tags}
            chip={true}
            resetValue={true}
            textInputProps={
              {
                placeholder: "Search: ex- Coding",
                underlineColorAndroid: "transparent",
                style: {
                    padding: 12,
                    borderWidth: 3,
                    borderColor: '#f0f3f5',
                    borderRadius: 5
                },
              }
            }
            listProps={
              {
                nestedScrollEnabled: true,
              }
            }
          />
        </KeyboardAvoidingView>
        </View>
      </TouchableWithoutFeedback>
  </View>
    );
  }
 }


 const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:"#fff"
  },
  
  button:{
    width:120,
    height:40,
    borderRadius:16,
    backgroundColor:"#5a89fa",
    alignItems:"center",
    justifyContent:"center",
    padding:5,
  },

header:{
  backgroundColor:"#fff",
  padding:10,
  flexDirection:"row",
  justifyContent:"space-between",
  borderBottomLeftRadius:10, 
  borderBottomRightRadius:10,
  borderWidth:1,
  borderColor:"#ccc",
  marginBottom:5,
  shadowColor: "#444",
  shadowOffset: {
     width: 10,
     height: 10,
  },
  shadowOpacity:100,
  shadowRadius: 100,
  elevation: 10, 
  },  



 
})

