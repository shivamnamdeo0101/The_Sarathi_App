import React from 'react';
import Fire from "../Fire";

import {
    Dimensions,
    StatusBar,
    ScrollView,
    Alert,  
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet
  } from "react-native";
import { AntDesign} from "@expo/vector-icons";
import { Dropdown } from 'react-native-material-dropdown';


const { width, height } = Dimensions.get("screen");

export default  class SchoolFormScreen extends React.Component {



    constructor(props) {
      super(props);
     this.state={ 
        SchoolName:"",
        State:"",
        Board:"",
        Class:"",
        Subject:"",
        Drop:"",
        Exams:"",
        user:{}
    };
  }



      //Fetch User Details
      componentDidMount() {
        const user  = this.props.uid || Fire.shared.uid;
    
        Fire.shared.firestore
        .collection("users")
        .doc(user)
        .onSnapshot(doc=>{
            this.setState({user:doc.data()});
            this.setState({SchoolName:this.state.user.SchoolName})
            this.setState({State:this.state.user.State})
            this.setState({Board:this.state.user.Board})
            this.setState({Class:this.state.user.Class})
            this.setState({Subject:this.state.user.Subject})
            this.setState({Drop:this.state.user.Drop})
            this.setState({Exams:this.state.user.Exams})
        });
    
    };
  UpdateDetails(SchoolName,State,Board,Class,Subject,Drop,Exams){
    console.log(this.state.SchoolName)
    console.log(this.state.State)
    console.log(this.state.Board)
    console.log(this.state.Class)
    console.log(this.state.Subject)
    console.log(this.state.Drop)
    console.log(this.state.Exams)
    const user  = this.props.uid || Fire.shared.uid;

    Fire.shared.firestore
    .collection("users")
    .doc(user)
    .set({
        SchoolName:this.state.SchoolName,
        State:this.state.State,
        Subject:this.state.Subject,
        Board:this.state.Board,
        Class:this.state.Class,
        Drop:this.state.Drop,
        Exams:this.state.Exams,

    }, { merge: true })
    .then(mydata=>{

      Alert.alert("Saved")
      this.props.navigation.navigate("Interest")
    })
    }
render() {  
    const { navigation } = this.props;
    let Boards = [{
      value: 'State Board',
    }, {
      value: 'CBSE',
    }, {
      value: 'ICSE',
    }, {
      value: 'IB School',
    }];
    let Classes = [{
      value: '1',
    }, {
      value: '2',
    }, {
      value: '3',
    }, {
      value: '4',
    }, {
      value: '5',
    }, {
      value: '6',
    }, {
      value: '7',
    }, {
      value: '8',
    }, {
      value: '9',
    }, {
      value: '10',
    }, {
      value: '11',
    }, {
      value: '12',
    }];

    let Subjects = [{
      value: 'Art',
    }, {
      value: 'Bio',
    }, {
      value: 'Commerce',
    }, {
      value: 'Maths',
    }];
    let Dropper = [{
      value: 'Yes',
    }, {
      value: 'No',
    }];
    let EntranceExams = [{
      value: 'NEET',
    }, {
      value: 'IIT-JEE',
    }];
    
    let States = [
        {
        value: 'Andaman and Nicobar Islands',
      }, {
        value: 'Andra Pradesh',
      }, {
        value: "Arunachal Pradesh",
      }, {
        value: 'Assam',
      }, {  
        value: 'Bihar',
      }, {
        value: 'Chhattisgarh',
      }, {
        value: 'Chandigarh',
      }, {
        value: 'Dadar and Nagar Haveli',
      }, {
        value: 'Daman and Diu',
      }, {
        value: 'Delhi',
      }, {
        value: 'Goa',
      }, {
        value: 'Gujarat',
      }, {
        value: 'Haryana',
      }, {
        value: 'Himachal Pradesh',
      }, {
        value: 'Jammu and Kashmir',
      }, {
        value: 'Jharkhand',
      }, {
        value: 'Karnataka',
      }, {
        value: 'Kerala',
      }, {
        value: 'Lakshadeep',
      }, {
        value: 'Madya Pradesh',
      }, {
        value: 'Maharashtra',
      }, {
        value: 'Manipur',
      }, {
        value: 'Meghalaya',
      }, {
        value: 'Mizoram',
      }, {
        value: 'Nagaland',
      }, {
        value: 'Orissa',
      }, {
        value: 'Punjab',
      }, {
        value: 'Pondicherry',
      }, {
        value: 'Rajasthan',
      }, {
        value: 'Sikkim',
      }, {
        value: 'Tamil Nadu',
      }, {
        value: 'Telagana',
      }, {
        value: 'Tripura',
      }, {
        value: 'Uttaranchal',
      }, {
        value: 'Uttar Pradesh',
      }, {
        value: 'West Bengal',
      }
    ];
    return(
     
   <View style={styles.container} >
      {/*Status Bar Light Content Color */}
      <StatusBar barStyle="light-content"></StatusBar>
     
      <View style={styles.header}>
       <View>
         <AntDesign onPress={() => {navigation.goBack()}} name="leftcircleo" size={30} color="#444" style={{paddingTop:6,paddingRight:30}}/>
       </View>
       <Text style={{fontSize:20,padding:5,paddingRight:10,color:"#444"}}>School Details</Text>

     </View>
     
        
      
     <ScrollView showsVerticalScrollIndicator={true}>
            <View style={{padding: 10}} >
            
                <View >
                  <TextInput
                    style={{ height: 50, borderColor: '#ccc', borderWidth: 2,paddingLeft:15,borderRadius:10}}
                    placeholder=" Enter School Name"
                  
                    
                    autoCorrect
                    multiline={true}
                  
                    placeholderTextColor  = "#545955"
                    defaultValue={this.state.user.SchoolName}
                    onChangeText={(text)=>this.setState({SchoolName:text})}
                  />
                </View>
                    <View >
                      <View>
                      <Dropdown
                            defaultValue={this.state.user.State}
                            label='Select States'
                            data={States}
                            fontSize={18}
                            labelFontSize={16}
                            baseColor="#7d7777"
                            textColor="#444"
                            itemPadding={8}
                            
                            onChangeText={(text) => this.setState({State:text})}
                            select
                        />
                      </View>
                    </View>

                    <View >
                    <View>
                      <Dropdown
                            defaultValue={this.state.user.Board}
                            label='Select Board'
                            data={Boards}
                            fontSize={18}
                            labelFontSize={16}
                            baseColor="#7d7777"
                            textColor="#444"
                            itemPadding={8}
                            onChangeText={(text) =>this.setState({Board:text})}
                            select
                        />
                      </View>
                    </View>
                    <View >
                    <View>
                      <Dropdown
                            defaultValue={this.state.user.Class}
                            label='Select Class'
                            data={Classes}
                            animationDuration={25}
                            fontSize={18}
                            labelFontSize={16}
                            baseColor="#7d7777"
                            textColor="#444"
                            itemPadding={8}
                            onChangeText={(text) =>this.setState({Class:text})}
                            select
                        />
                      </View>
                    </View>
                    {
                      (this.state.Class > 10) ?
                          <View >
                        <View >
                          <Dropdown
                                defaultValue={this.state.user.Subject}
                                label='Select Subjects'
                                data={Subjects}
                                animationDuration={225}
                                fontSize={18}
                                labelFontSize={16}
                                baseColor="#7d7777"
                                textColor="#444"
                                itemPadding={8}
                                onChangeText={(text) =>this.setState({Subject:text})}
                                select
                            />
                          </View>
                        </View>
                    :
                        <View>
                        </View>
                    }

                  <View >
                    <View>
                      <Dropdown
                            defaultValue={this.state.user.Drop}
                            label='Dropper'
                            data={Dropper}
                            animationDuration={225}
                            fontSize={18}
                            labelFontSize={16}
                            baseColor="#7d7777"
                            textColor="#444"
                            itemPadding={8}
                            onChangeText={(text) =>this.setState({Drop:text})}
                            select
                        />
                      </View>
                    </View>

                    {
                      (this.state.Drop=="Yes") ?
                      <View  >
                        <View>
                          <Dropdown
                                defaultValue={this.state.user.Exams}
                                label='Which Entrance Exams you are preparing for'
                                data={EntranceExams}
                                animationDuration={225}
                                fontSize={18}
                                labelFontSize={16}
                                baseColor="#7d7777"
                                textColor="#444"
                                itemPadding={8}
                                onChangeText={(text) =>this.setState({Exams:text})}
                                select
                            />
                          </View>
                        </View>
                    :
                        <View>
                        </View>
                    }
                 

                 <TouchableOpacity style={{alignSelf:"center"},styles.button}
                    
                    onPress={() => 
                      this.UpdateDetails(
                        this.state.SchoolName,
                        this.state.State,
                        this.state.Board,
                        this.state.Class,
                        this.state.Subject,
                        this.state.Drop,
                        this.state.Exams,
                        )} 
                    >
                    
                    
                      <Text style={{color:"#f0f3f5",fontSize:18}}>Save Details</Text>
                    </TouchableOpacity>
            
         </View>

          </ScrollView> 
  </View>


    );
  }
 }


 const styles = StyleSheet.create({
  container: {
      flex: 1,
      backgroundColor:"#fff"
  },
  header:{
    backgroundColor:"#fff",
    padding:10,
    flexDirection:"row",
    justifyContent:"space-between",
   borderBottomLeftRadius:10, 
   borderBottomRightRadius:10,
   borderWidth:1,
   borderColor:"#ccc",
   marginBottom:20,
   shadowColor: "#444",
   shadowOffset: {
     width: 10,
     height: 10,
   },
   shadowOpacity:100,
   shadowRadius: 100,
   elevation: 10, 
  },  

  button:{
    
    width:120,
    height:40,
    borderRadius:16,
    backgroundColor:"#5a89fa",
    alignItems:"center",
    justifyContent:"center",
    padding:5,
    marginBottom:30,

    
},



 
})