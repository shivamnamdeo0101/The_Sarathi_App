import React,{Component} from "react";
import {View,Text,StyleSheet,TouchableOpacity,StatusBar,Alert} from "react-native";
import {Ionicons} from '@expo/vector-icons';
import { FontAwesome5 ,AntDesign } from '@expo/vector-icons';

import Fire from "../Fire";


export default class EditProfileScreen extends Component {  



   
    state = {
        Qualification:"",
    };


    //Fetch User Details
    InsertQualification() {
        const user  = this.props.uid || Fire.shared.uid;

        Fire.shared.firestore
        .collection("users")
        .doc(user)
        .set({
            Qualification:this.state.Qualification,
        }, { merge: true })
        

    };


    addQualification = () => {
        console.log(this.state.Qualification)
       
        if(this.state.Qualification=='School'){
            this.props.navigation.navigate("SchoolForm")
        }
        else if(this.state.Qualification=='College'){
            this.props.navigation.navigate("CollegeForm")
        }
        else if(this.state.Qualification=='PassOut'){
            this.props.navigation.navigate("Interest")
        }
        else{
            Alert.alert("Please Select One")
        }
        this.InsertQualification();
    }
  
    render() {  
        return (  
            
            <View style={styles.container}>  

                <StatusBar barStyle="light-content"></StatusBar>

                <View style={styles.back}>  
                    <TouchableOpacity onPress={()=>this.props.navigation.goBack()}>
                        <AntDesign name="leftcircleo" size={38} color="#444449" />
                    </TouchableOpacity>
                </View>


                <View style={{width:"80%",height:50,backgroundColor:"#FFF",
                    justifyContent:"center",alignSelf:"center",borderRadius:20,marginTop:10}}>
                    <Text style={{fontSize:20,textAlign:"center",color:"#444449"}}>ARE YOU IN...?</Text>
                </View>
               
                <View style={styles.innerContainer}>  

                    <TouchableOpacity onPress={() => {this.setState({ Qualification: "College"}, function() { this.addQualification() })}}>
                        <Ionicons name="ios-school" size={80} color="#444449" />
                        <Text  style={{fontSize:20,paddingLeft:10,paddingTop:10,color:"#444449"}}>COLLEGE</Text>
                    </TouchableOpacity>

                    <Text style={{fontSize:20,color:"#444449"}}>
                        OR
                    </Text>

                    <TouchableOpacity onPress={() => {this.setState({ Qualification: "School"}, function() { this.addQualification() })}}>
                        <FontAwesome5 name="school" size={60} color="#444449" 
                        />
                        <Text>            </Text>
                        <Text style={{fontSize:20,paddingLeft:10,paddingTop:10,color:"#444449"}}>SCHOOL</Text>
                    </TouchableOpacity>

                    




                </View>  
                <TouchableOpacity style={{alignSelf:"center",marginBottom:110}}onPress={() => {this.setState({ Qualification: "PassOut"},function() { this.addQualification() })}}>
                       
                        <FontAwesome5 name="user-graduate" size={60} color="#444449"
                        />
                        <Text style={{fontSize:20,paddingTop:10,color:"#444449",textAlign:"center"}}>PASSOUT</Text>
             </TouchableOpacity>
                    

         
            </View>  
        );  
    }  
}  
  
const styles = StyleSheet.create({  
    container: {  
        flex:1,
        borderRadius:10,
        backgroundColor: "#f0f3f5",  
        padding:30
    },  
    innerContainer:{  
        flex: 1,  
        width: "100%",  
        flexDirection: "row",  
        justifyContent: "space-evenly",  
        alignItems: "center" ,
        marginBottom:10,

       

    },
    back:{
        width: "100%",  
        flexDirection: "row",  
        justifyContent: "space-between",  
        alignItems: "center" ,
    },

});  