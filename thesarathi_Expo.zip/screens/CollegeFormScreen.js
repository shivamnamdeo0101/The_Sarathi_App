import React from 'react';
import {AntDesign} from "@expo/vector-icons";
import Fire from "../Fire";


import {
    StyleSheet,
    StatusBar,
    TouchableOpacity,
    KeyboardAvoidingView,
    ScrollView,
    Alert,  
    View,
    Text,
    TextInput,

  } from "react-native";

  import { Dropdown } from 'react-native-material-dropdown';



export default class CollegeFormScreen extends React.Component {
  state={ 
    CollegeName:"",
    CollegeLocation:"",
    Branch:"",
    CurrentYear:"",
    Category: "",
    UGDegree: "",
    PGDegree: "",
    user:{}
  };

  //Fetch User Details
  componentDidMount() {
    const user  = this.props.uid || Fire.shared.uid;

    Fire.shared.firestore
    .collection("users")
    .doc(user)
    .onSnapshot(doc=>{
        this.setState({user:doc.data()});
        this.setState({CollegeName:this.state.user.CollegeName})
      this.setState({Branch:this.state.user.Branch})
      this.setState({Category:this.state.user.Category})
      this.setState({CurrentYear:this.state.user.CurrentYear})
      this.setState({UGDegree:this.state.user.UGDegree})
      this.setState({PGDegree:this.state.user.PGDegree})
      this.setState({CollegeLocation:this.state.user.CollegeLocation})
    })
    

};


  UpdateDetails(CollegeName,CollegeLocation,Branch,Category,CurrentYear,UGDegree,PGDegree){
    console.log(this.state.CollegeName)
    console.log(this.state.CollegeLocation)
    console.log(this.state.Branch)
    console.log(this.state.Category)
    console.log(this.state.CurrentYear)
    console.log(this.state.UGDegree)
    console.log(this.state.PGDegree)

    const user  = this.props.uid || Fire.shared.uid;

    Fire.shared.firestore
    .collection("users")
    .doc(user)
    .set({
        CollegeName:this.state.CollegeName,
        CollegeLocation:this.state.CollegeLocation,
        Branch:this.state.Branch,
        CurrentYear:this.state.CurrentYear,
        Category:this.state.Category,
        UGDegree:this.state.UGDegree,
        PGDegree:this.state.PGDegree,

    }, { merge: true })
    .then(mydata=>{
        Alert.alert("Saved")
        this.props.navigation.navigate("Interest")
      })
    }
render() {  
    const { navigation } = this.props;
    let Categories = [{
      value: 'Under Graduation',
    }, {
      value: 'Post Graduation',
    }];

    let UG = [{
      value: 'Bachelor of Arts',
    }, {
      value: 'Bachelor of Science',
    }, {
      value: 'Bachelor of Commerce',
    }, {
      value: 'Bachelor of Engg./Tech',
    }, {
      value: 'BMS/BBA/BBS',
    }, {
      value: 'Bachelor of Law',
    }, {
      value: 'Bachelor of Medicine (MBBS)',
    }, {
      value: 'IIM 5-year Integrated Mgmt. Programme',
    }];
    let PG = [{
      value: 'Masters of Art (MA)',
    }, {
      value: 'Master of Science (MSc)',
    }, {
      value: 'Master in Fine Arts (MFA) ',
    }, {
      value: 'The Master of Laws (LLM)',
    }, {
      value: 'Master in Engineering (ME)/ (M-Tech)',
    }, {
      value: 'Postgraduate Certified (PG Cert) and Postgraduate Diploma (PGD)',
    }, {
      value: 'Master of Research (MRes)',
    }, {
      value: 'Masters in Business Administration (MBA)',
    }, {
      value: 'Master in Philosophy (MPhil)',
    }];
    let Branches = [{
      value: 'Civil Engineering',
    }, {
      value: 'Electrical Engineering',
    }, {
      value: 'Mechanical Engineering',
    }, {
      value: 'Industrial and Production Engineering',
    }, {
      value: 'Electronics and Instrumentaion Engineering',
    }, {
      value: 'Computer Science',
    }, {
      value: 'Bio-Medical Engineering',
    }, {
      value: 'Electronics and Communication Engineering',
    }, {
      value: 'Information Technology Engineering',
    }, {
      value: 'Pharmacy',
    }, {
      value: 'Applied Physics',
    }, {
      value: 'Applied Chemistry',
    }, {
      value: 'Applied Mathematics',
    }, {
      value: 'Humanities and Social Science',
    }, {
      value: 'Computer Technology and Management',
    }];
    let Year = [{
      value: 'I Year',
    }, {
      value: 'II year',
    }, {
      value: 'III year',
    }, {
      value: 'Final Year',
    }];    
    let States = [
        {
        value: 'Andaman and Nicobar Islands',
      }, {
        value: 'Andra Pradesh',
      }, {
        value: "Arunachal Pradesh",
      }, {
        value: 'Assam',
      }, {  
        value: 'Bihar',
      }, {
        value: 'Chhattisgarh',
      }, {
        value: 'Chandigarh',
      }, {
        value: 'Dadar and Nagar Haveli',
      }, {
        value: 'Daman and Diu',
      }, {
        value: 'Delhi',
      }, {
        value: 'Goa',
      }, {
        value: 'Gujarat',
      }, {
        value: 'Haryana',
      }, {
        value: 'Himachal Pradesh',
      }, {
        value: 'Jammu and Kashmir',
      }, {
        value: 'Jharkhand',
      }, {
        value: 'Karnataka',
      }, {
        value: 'Kerala',
      }, {
        value: 'Lakshadeep',
      }, {
        value: 'Madya Pradesh',
      }, {
        value: 'Maharashtra',
      }, {
        value: 'Manipur',
      }, {
        value: 'Meghalaya',
      }, {
        value: 'Mizoram',
      }, {
        value: 'Nagaland',
      }, {
        value: 'Orissa',
      }, {
        value: 'Punjab',
      }, {
        value: 'Pondicherry',
      }, {
        value: 'Rajasthan',
      }, {
        value: 'Sikkim',
      }, {
        value: 'Tamil Nadu',
      }, {
        value: 'Telagana',
      }, {
        value: 'Tripura',
      }, {
        value: 'Uttaranchal',
      }, {
        value: 'Uttar Pradesh',
      }, {
        value: 'West Bengal',
      }
    ];
    return(

<View style={styles.container}>
     {/*Status Bar Light Content Color */}
      <StatusBar barStyle="light-content"></StatusBar>
     
      <ScrollView showsVerticalScrollIndicator={true}>
      <View style={styles.header}>
       <View>
         <AntDesign onPress={() => {navigation.goBack()}} name="leftcircleo" size={30} color="#444" style={{paddingTop:6,paddingRight:30}}/>
       </View>
       <Text style={{fontSize:20,padding:5,paddingRight:10,color:"#444"}}>College Details</Text>
      
     </View>
                   



      <View style={{padding:10}}>
        <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding" enabled>
            <View>
              <TextInput
                style={{ height: 50, borderColor: '#ccc', borderWidth: 2,paddingLeft:20,borderRadius:5}}
                placeholderTextColor  = "#545955"
                defaultValue={this.state.user.CollegeName}
                onChangeText={(text)=>this.setState({CollegeName:text})}
                placeholder="College Name"
                autoCapitalize="words"
                autoCompleteType="name"
                clearTextOnFocus={true}
                multiline={true}
                editable={true}
                
            />
            </View>
        <View>
            <Dropdown
                 defaultValue={this.state.user.CollegeLocation}
              label='College Location'
              data={States}
              fontSize={18}
              labelFontSize={16}
              baseColor="#7d7777"
              textColor="#444"
              itemPadding={8}
              onChangeText={(text) => this.setState({CollegeLocation:text})}
              select
            />
       </View>
        <View>
         <Dropdown
            defaultValue={this.state.user.Category}
            label='Select Category'
            data={Categories}
            fontSize={18}
            labelFontSize={16}
            baseColor="#7d7777"
            textColor="#444"
            itemPadding={8}
            onChangeText={(text) => this.setState({Category:text})}
            select                
          />
        </View>
        {
            (this.state.Category == 'Under Graduation') ?
                <View>
                  <Dropdown
                    defaultValue={this.state.user.UGDegree}
                    label='Select UG Course'
                    data={UG}
                    animationDuration={225}
                    fontSize={18}
                    labelFontSize={16}
                    baseColor="#7d7777"
                    textColor="#444"
                    itemPadding={8}
                    onChangeText={(text) =>this.setState({UGDegree:text})}
                    select
                  />
                  </View>
                    :
                        <View>
                          <Dropdown
                                 defaultValue={this.state.user.PGDegree}
                                label='Select PG Course'
                                data={PG}
                                animationDuration={225}
                                fontSize={18}
                                labelFontSize={16}
                                baseColor="#7d7777"
                                textColor="#444"
                                itemPadding={8}
                                onChangeText={(text) =>this.setState({PGDegree:text})}
                                select
                            />
                        </View>
                    }
                    {
                      (this.state.UGDegree == 'Bachelor of Engg./Tech') ?
                          <View>
                          <Dropdown
                           defaultValue={this.state.user.Branch}
                                label='Select Branch'
                                data={Branches}
                                animationDuration={225}
                                fontSize={18}
                                labelFontSize={16}
                                baseColor="#7d7777"
                                textColor="#444"
                                itemPadding={8}
                                onChangeText={(text) =>this.setState({Branch:text})}
                                select
                            />
                        </View>
                    :
                        <View>
                      
                        </View>
                    }

                  <View >
                      <Dropdown
                       defaultValue={this.state.user.CurrentYear}
                            label='Year'
                            data={Year}
                            animationDuration={225}
                            fontSize={18}
                            labelFontSize={16}
                            baseColor="#7d7777"
                            textColor="#444"
                            itemPadding={8}
                            onChangeText={(text) =>this.setState({CurrentYear:text})}
                            select
                        />
                    </View>
                    <TouchableOpacity style={{alignSelf:"center"},styles.button}
                    onPress={() => 
                        this.UpdateDetails(
                          this.state.CollegeName,
                          this.state.CollegeLocation,
                          this.state.Category,
                          this.state.Branch,
                          this.state.CurrentYear,
                          this.state.UGDegree,
                          this.state.PGDegree,
                          )} 
                      >
                      <Text style={{color:"#f0f3f5",fontSize:18}}>Save Details</Text>
                    </TouchableOpacity>
                  
                </KeyboardAvoidingView>
         </View>
         </ScrollView>
  </View>
    );
  }
 }



 const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:"#fff"
  },
  
  button:{
    width:120,
    height:40,
    borderRadius:16,
    backgroundColor:"#5a89fa",
    alignItems:"center",
    justifyContent:"center",
    padding:5,
  },

header:{
  backgroundColor:"#fff",
  padding:10,
  flexDirection:"row",
  justifyContent:"space-between",
  borderBottomLeftRadius:10, 
  borderBottomRightRadius:10,
  borderWidth:1,
  borderColor:"#ccc",
  marginBottom:20,
  shadowColor: "#444",
  shadowOffset: {
     width: 10,
     height: 10,
  },
  shadowOpacity:100,
  shadowRadius: 100,
  elevation: 10, 
  },  



 
})
