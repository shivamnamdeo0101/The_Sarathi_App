import React from 'react'
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity, Image, TextInput ,Alert} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import Constants from 'expo-constants'
import * as Permissions from 'expo-permissions'
import Fire from '../Fire'
import * as ImagePicker from 'expo-image-picker'
import { ScrollView } from 'react-native-gesture-handler';
import { WebView } from 'react-native-webview';


const firebase = require("firebase");
require("firebase/firestore");

export default class PostScreen extends React.Component {
    state = {
        title:"",
        text: "",
        image: '../assets/icon.png',
        video:"",
    }


    //get permissiion
    componentDidMount() {
        this.getPhotoPermission();
    }

    getPhotoPermission = async () => {
        if (Constants.platform.ios) {
            const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL)

            if (status != "granted") {
                alert("Permission Required ")
            }
        }
    };
//Post Data

    handlePost = () => {
        Fire.shared
            .addPost({ title:this.state.title.trim(),text: this.state.text.trim(),video:this.state.video.trim(), localUri: this.state.image })
            .then(ref => {
               this.setState({ title:"",text: "", image: null,video:"" });
                Alert.alert("Posted");
                this.props.navigation.goBack();

            })
            .catch(error => {
                alert(error.message);
            });
    };


//Image Picker Function
    pickImage = async () => {
        let result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
         
            quality:0.4,
        })

        if (!result.cancelled) {
            this.setState({ image: result.uri });
        }
    }



    

    render() {
        return (
            <SafeAreaView style={styles.container}>

                {/* Header */}
                <View style={styles.header}>
                    <TouchableOpacity onPress={() => this.props.navigation.goBack()}>
                        <Ionicons name="md-arrow-back" size={24} color="#D8D9DB"></Ionicons>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={this.handlePost}>
                        <Text style={{ fontWeight: "500" }}>Post</Text>
                    </TouchableOpacity>
                </View>


                {/*  Input Filed With SrollView*/}
                <ScrollView showsVerticalScrollIndicator={false}>
                <View style={styles.inputContainer}>
                    <Image source={require("../assets/page/img.png")} style={styles.avatar}></Image>
                    
                     <Text>Title : </Text>


                    <TextInput
                        autoFocus={true}
                        multiline={true}
                        numberOfLines={4}
                        placeholder="Title"
                        onChangeText={title => this.setState({ title })}
                        value={this.state.title}>
                    </TextInput>
                    
                    <Text>Description : </Text>


                    <TextInput
                        autoFocus={true}
                        multiline={true}
                        numberOfLines={4}
                        placeholder="Description"
                        onChangeText={text => this.setState({ text })}
                        value={this.state.text}>
                    </TextInput>

                    <Text>Embeded Video Link : </Text>

                    <TextInput
                        autoFocus={true}
                        multiline={true}
                        numberOfLines={4}
                        placeholder="Embeded Video"
                        onChangeText={video => this.setState({ video })}
                        value={this.state.video}>
                    </TextInput>



                </View>

                {/* Image Pick*/}
                <TouchableOpacity style={styles.photo} onPress={this.pickImage}>
                    <Ionicons name="md-camera" size={32} color="#D8D9DB"></Ionicons>
                </TouchableOpacity>

               

                {/* Show Image Picked*/}
                <View style={{marginTop: 32,  marginBottom:20,height:200,width:"100%"  }}>
                    <Image source={{ uri: this.state.image }} style={{ width: "100%", height: "100%" }}></Image>
                </View>

                {/* Show Image Picked*/}
                <View style={{marginTop: 32,  marginBottom:20,height:200,width:"100%"  }}>
                <WebView
                style={{ width: "100%", height: "100%" }}
                javaScriptEnabled={true}
                domStorageEnabled={true}
                source={{uri: this.state.video }}
              />
              
           
                </View>


              
                </ScrollView>

            </SafeAreaView>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    header: {
        marginTop: 30,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: 32,
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: "#D8D9DB"
    },
    inputContainer: {
        margin:20,
        padding:10,
        flexDirection: "column",
       
   
    },
    avatar: {
        marginTop: 10,
        marginBottom:40,
        width: 48,
        height: 48,
        borderRadius: 24,
        marginRight: 10
    },
    photo: {
        alignItems: "flex-end",
        marginHorizontal: 32,

    }
})