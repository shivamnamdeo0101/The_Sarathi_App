import React ,{useState,Component}from 'react';
import { View, Text, StyleSheet, TouchableOpacity, 
  Button,LayoutAnimation , RefreshControl,StatusBar,Modal,ScrollView, Platform,
   FlatList,Image,ImageBackground} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import moment from "moment";
import firebase from "firebase";
import Constants from 'expo-constants';
import Fire from "../Fire";

import { WebView } from 'react-native-webview';
import { TextInput } from 'react-native-gesture-handler';

const post_list = [];

export default class HomeScreen extends React.Component {



  
  constructor(props) {
    
    super(props);
    this.state = {
      posts: [],
      isDataLoaded: false,
      isFetching: false,
      user:{},
      
    }
  }


//Filter Function
    //SearchFilterFunction = (e) => {
    //  let text = e.toLowerCase()
    //  let trucks = post_list["title"]
    //  let filteredName = trucks.filter((item) => {
    //    console.log(item)
    //    return item.title.toLowerCase().match(text)
      //
    //  })
    //  if (!text || text === '') {
    //    this.setState({
    //      post_list: ""
    //    })
    //  } else if (!Array.isArray(filteredName) && !filteredName.length) {
    //    // set no data flag to true so as to render flatlist conditionally
    //    this.setState({
    //      noData: true
    //    })
    //  } else if (Array.isArray(filteredName)) {
    //    this.setState({
    //      noData: false,
    //      post_list: filteredName
    //      
    //    })
    //  }
    //}


  //List Refresh
  onRefresh() {
    this.setState({ isFetching: true }, function() { this.searchRandomUser() });
   
  }
  

 //Random user
 searchRandomUser = async () =>{
    const RandomAPI = await fetch('https://randomuser.me/api/?results=20')
    const APIValue = await RandomAPI.json();
     const APIResults = APIValue.results
       console.log(APIResults[0].email);
       this.setState({
           data:APIResults,
           isFetching: false
       })

 }

  //Fetch Data OF Post
  componentDidMount(){
    
    firebase.firestore()
    .collection('posts')
    .orderBy('timestamp', 'desc')
    .get()
    .then(doc =>{
     doc.forEach(doc => {
       if (doc.data().video) {
        console.log("video")
       }else if(doc.data().image){
        console.log("image")
       }
       
        post_list.push({
          id: doc.data().uid,
          title:doc.data().title,
          text: doc.data().text,
          timestamp: doc.data().timestamp,
          image: doc.data().image,
          video:doc.data().video,
        }); 
      });
    });


    //Get  User details 
    const user  = this.props.uid || Fire.shared.uid;

        Fire.shared.firestore
        .collection("users")
        .doc(user)
        .onSnapshot(doc=>{

            this.setState({user:doc.data()});
        });

    
  
  }


  //Stop Fetching
    UNSAFE_componentWillMount(){
      
      this.searchRandomUser()
      this.setState({
      posts: post_list,
      isDataLoaded: true
    })
  }



  renderPost = post =>{
    return(
      

      //Send Post Data To Modal Screen
      <View style={styles.feedItem}

      >
        {/* Posts List*/}
          <View style={{flex:1}}>
              <View style={{flexDirection:"row",justifyContent:"space-between",alignItems:"center",width:"100%"}}>
              </View>
              
              {
                (post.video) ? 

                <WebView
                style={ styles.postImage }
                javaScriptEnabled={true}
                domStorageEnabled={true}
                source={{uri: post.video }}
              />

              :


           <Image source={{uri:post.image}} style={styles.postImage}/>
            
              }

            
                <TouchableOpacity style={styles.text}
                        onPress={() =>  
                          this.props.navigation.navigate('Message', {  
                              title:post.title,
                              image: post.image, 
                              time: moment(post.timestamp).fromNow(), 
                              text: post.text, 
                              video:post.video 
                              
                          })  
                      }  
                >
               
                  <Text style={styles.timestamp}>{moment(post.timestamp).fromNow()}</Text>
                  <View style={{flexDirection:"row"}}>
                  <Text style={styles.post}>{post.title.substring(0, 80)}...</Text>
                    
                  </View>
                  
                </TouchableOpacity>

               
                  
          </View>
      </View>
    );
  };


  render() {
    LayoutAnimation.easeInEaseOut();

    if(this.state.isDataLoaded && this.state.posts){
    return (

      
      <ImageBackground source={require("../assets/bg.jpg")} style={{width:"100%",height:"100%"}}>
         {/* Header */}


        <View style={styles.container}>
            <StatusBar barStyle="light-content"/>
        <View style={styles.header}>
        
           <TouchableOpacity style={{flexDirection:"row"}} onPress={() => this.props.navigation.navigate("Profile")}>
              <Image style={styles.img} source={this.state.user.avatar ? { uri: this.state.user.avatar } : require("../assets/page/user.png")}/>
              {/*<Text style={styles.user}> {this.state.user.name}</Text>  */}
           </TouchableOpacity>

           <TextInput style={styles.searchInput} 
           placeholder="Search For..."
           
          >
          
           </TextInput>


          <TouchableOpacity 
         
          onPress={() => this.props.navigation.navigate("Notification")}
           >
            <Ionicons name="ios-notifications"
              size={30} color="#444" />
           </TouchableOpacity>

        </View>
          <FlatList 

            style={styles.feed}
            
            data={this.state.posts}
            renderItem={({ item })=> this.renderPost(item)}
            keyExtractor={(item, index) => String(index)}
            showsVerticalScrollIndicator={false}
            onRefresh={() => this.onRefresh()}
            refreshing={this.state.isFetching}
            RefreshControl
          />
      
         

        </View>
        </ImageBackground>
    )
    }else{
     
      return (<Text> Waiting for data</Text>)
    }
}
}


const styles = StyleSheet.create({
  container: {
      flex: 1, 
  },
  header:{

    backgroundColor:"#fff",
    paddingBottom:5,
    flexDirection:"row",
    padding:12,
    justifyContent:"space-between",
    borderBottomLeftRadius:15,
    borderBottomRightRadius:15,
    shadowColor: "#404",
    shadowOffset: {
      width: 100,
      height: 120,
    },
    shadowOpacity:1000,
    shadowRadius: 100,
    elevation: 100, 

  },
  feedItem:{
    flexDirection:"row",
    marginVertical:8,
    marginBottom:34,
    shadowColor: "#404",
    shadowOffset: {
      width: 1000,
    height: 120,
    },
    shadowOpacity:1000,
    shadowRadius: 100,
    elevation: 100, 
    
  },
  img:{
    width:40,
    height:40,
    borderRadius:20,
  },
  WebViewContainer: {

    marginTop: (Platform.OS == 'android') ? 20 : 0,

  },

  searchInput:{
    width:"65%",
    backgroundColor:"#f0f3f5",
    height:"90%",
    borderRadius:20,
    paddingLeft:20,
    paddingRight:20,
 
  },

  timestamp:{
    fontSize:13,
    color:"#C4C6CE",
    marginTop:4,
    marginBottom:4,
    textAlign:"left",
  },
  user:{
    fontSize:15,
    color:"#444449",
    marginTop:8,
    marginHorizontal:10,
    shadowColor: "#404",
    shadowOffset: {
      width: 12,
    height: 12,
    },
    shadowOpacity:100,
    shadowRadius: 100,

  },
  post:{
    fontSize:14,
    color:"#444",
    fontWeight:"bold",
    shadowColor: "#404",
    shadowOffset: {
      width: 1000,
    height: 120,
    },
    shadowOpacity:1000,
    shadowRadius: 100,
    elevation: 100, 
    
  },
  text:{
    padding:20,
    width:"85%",
    backgroundColor:"#fff",
    alignSelf:"center",
    marginTop:-8,
    borderRadius:10,
    shadowColor: "#404",
    shadowOffset: {
      width: 1000,
    height: 120,
    },
    shadowOpacity:1000,
    shadowRadius: 100,
    elevation: 100, 
  

  },
  postImage:{
    width:"90%",
    height:182,
    alignSelf:"center",
    borderRadius:10,
    opacity:0.8,
    borderRadius:10,
    borderColor:"#f0f3f5",
    borderWidth:1,
    shadowColor: "#404",
    shadowOffset: {
      width: 1000,
    height: 120,
    },
    shadowOpacity:1000,
    shadowRadius: 100,
  
  }

})