import React, { Component} from "react";
import {View,Text,StyleSheet,Image, SafeAreaView,Share,Button,Linking,ImageBackground} from "react-native";
import {Ionicons,AntDesign,FontAwesome5} from '@expo/vector-icons';
import {StatusBar} from "react-native";
import { TouchableOpacity, ScrollView } from "react-native-gesture-handler";
import * as FileSystem from 'expo-file-system';
import * as Permissions from 'expo-permissions';
import * as MediaLibrary from 'expo-media-library';
import * as Sharing from 'expo-sharing';



export default class MessageScreen extends React.Component{

    
    render(){

        //Get Data From Home
        const { navigation } = this.props;  
        const text = navigation.getParam('text', 'NO-text');  
        const image = navigation.getParam('image', 'NO-Image');  
        const time = navigation.getParam('time', 'NO-Time');  
        const title = navigation.getParam('title', 'NO-title');  

        //Sahe Function
        const onShare = async () => {
          FileSystem.downloadAsync(
            image,
            FileSystem.documentDirectory  + '.jpeg'
          )
            .then(({ uri }) => { 
                console.log('Finished downloading to ', uri);

                const options ={
                  url:uri,
                  message:text,
                }

                let url = 'whatsapp://send?text='+encodeURIComponent(uri);
                Linking.openURL(url);
               // Share.share(url);
                //Sharing.shareAsync(uri); 
            })
            .catch(error => {
              console.error(error); 
            });
          };


        return(
          <ImageBackground  style={{width:"100%",height:"100%"}}>

      
            <View style={styles.container}>
                <StatusBar barStyle="light-content"/>
                <Image source={{uri: image}} style={styles.image} />
                <View style={styles.cover_text}>
                    
                    
                    <SafeAreaView>
                        <ScrollView showsVerticalScrollIndicator={false}>

                        <Text style={{color:"#444449",fontWeight:"bold",padding:20,fontSize:22}}>
                            {title}
                        </Text>
                        <Text style={styles.time}>{time}</Text>
                        <Text style = {styles.item}>{text}</Text>
                            
                        </ScrollView>   
                    </SafeAreaView>
                    
                </View>
                
                
                
            </View>
            </ImageBackground>
        );
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,   
   
    },
    image: {
      justifyContent: "center",
      width:"100%",
      height:200,
      opacity:0.8,
      borderBottomRightRadius:20,
      borderBottomLeftRadius:20,
      alignSelf:"center",

      

    },
    item: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 15,
        marginBottom:"80%",  
        fontSize:18
            
     },
    cover_text:{
      
        padding:20, 
        paddingBottom:100,
        borderRadius:30,
        backgroundColor:"#f9f3f9",
        margin:15,
        shadowColor: "#404",
        shadowOffset: {
          width: 100,
        height: 120,
        },
        shadowOpacity:100,
        shadowRadius: 100,
        elevation: 14, 
       
    },
    time:{
        fontSize:13,
        color:"#444",
        marginTop:12,
        marginBottom:8,
        textAlign:"center",
    }
  });
  