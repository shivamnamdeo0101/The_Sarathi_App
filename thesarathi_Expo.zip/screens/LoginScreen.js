import React from 'react';
import { StyleSheet, Text, View ,TouchableOpacity,Image,StatusBar,LayoutAnimation,ImageBackground} from 'react-native';
import * as firebase from "firebase";
import { AntDesign } from '@expo/vector-icons';
import * as Google from 'expo-google-app-auth';


export default class LoginScreen extends React.Component {

  //Remove Unwanted Header
  static navigationOptions = {
    headerShown:false
  };

  ///State for user
  state = {
    email:"",
    password:"",
    errorMessage:null
  };

  ///Login Function
  handleLogin = ()=>{
    const {name,email ,password} = this.state

    firebase.auth().signInWithEmailAndPassword(email,password)
    .catch(error => this.setState({errorMessage:error.message}))
  };

  signInWithGoogleAsync= async () => {
      try {
        const { type, user } = await Google.logInAsync({
          behaviour: 'web',
          androidStandaloneAppClientId: '303537616637-m0ulijq4jefn8al9s2ugal1jiq1cn396.apps.googleusercontent.com',
          androidClientId: '303537616637-m0ulijq4jefn8al9s2ugal1jiq1cn396.apps.googleusercontent.com',
          scopes: ['profile', 'email'],
        })
        if (type === 'success') {
          this.setState({ 
            email:user.email,
            password:user.name,
          });
          this.handleLogin();
          }
          console.log(user.name);
          console.log(user.photoUrl);
          console.log(user.email);
      } catch ({ message }) {
        alert('login: Error:' + message);
    }
  }
  


  
  render(){

    LayoutAnimation.easeInEaseOut();
    return(
      <ImageBackground source={require("../assets/bg.jpg")} style={{width:"100%",height:"100%"}}>
      <View style={styles.container }>
    
         {/*Status Bar Light Content Color */}
          <StatusBar barStyle="light-content"></StatusBar>

          {/* Header Image */}
          <View style={{flexDirection:"column",justifyContent:"space-evenly",marginTop:50}}>
            <Text style={styles.greeting}>Welcome Back<Text style={{color:"#348ceb"}}>!</Text></Text>
            <Text style={{color:"#348ceb",fontSize:10}}></Text>   
          </View>
      
        {/**  Login Form*/}

      <View style={styles.form}> 
       
        {/*Social Login*/}
        <Text style={{color:"#414959",fontSize:25,marginBottom:4,alignSelf:"center",fontWeight:"bold"}} >{`\n`}SIGN IN</Text>
        <View style={{flexDirection:"column",alignSelf:"center",justifyContent:"space-evenly"}}>
        
        <TouchableOpacity style={styles.social} onPress={this.signInWithGoogleAsync} >
            <Text style={{color:"#fff",fontSize:18}}>Sign In Using Google</Text>
            <AntDesign name="google" size={24} color="#fff" />
        </TouchableOpacity>
     
        
        </View>

        {/**  Error Message*/}
        <View style={styles.errorMessage}> 
             {
              this.state.errorMessage &&
               <Text style={styles.error}>
                 {this.state.errorMessage}
               </Text>
             }
        </View>
        
          {/*Signup Login Switch*/}
        <TouchableOpacity style={{alignSelf:"center",marginTop:10}}
           onPress={()=>
            this.props.navigation.navigate("Register")
          }
        >
          <Text style={{color:"#414959",fontSize:18,marginBottom:15}}
        
          >
            New To The Sarathi ? <Text style={{fontWeight:"500",color:"#1a95e8",fontWeight:"bold"}}>Sign up</Text>
          </Text>
        </TouchableOpacity>

         {/**  Login Form*/}

      </View>

      </View>
      </ImageBackground>

    );
  }
}

const styles = StyleSheet.create({
  container:{
    flex:1,
  },
  greeting:{
    marginBottom:-40,
    color:"#444",   
    fontSize:60,
    fontWeight:"bold",
    textAlign:"left",
    marginLeft:40,
   
  },

  error:{
    color:"#f74343",
    fontSize:13,
    fontWeight:"600",
    textAlign:"center",

  },
  errorMessage:{
    alignItems:"center",
    justifyContent:"center",
    marginTop:8
  },
  form:{
    marginHorizontal:20,
    backgroundColor:"#f0f3f5",
    padding:10,
    borderRadius:30,
    marginTop:100,
    shadowColor: "#404",
    shadowOffset: {
      width: 1000,
    height: 120,
    },
    shadowOpacity:100,
    shadowRadius: 100,
    elevation: 50, 
  },

  social:{
    marginTop:15,
    width:220,
    height:50,
    borderRadius:16,
    backgroundColor:"#348ceb",
    alignItems:"center",
    justifyContent:"center",
    padding:20,
    flexDirection:"row",
    justifyContent:"space-around",
    shadowColor: "#404",
    shadowOffset: {
      width: 1000,
    height: 120,
    },
    shadowOpacity:100,
    shadowRadius: 100,
    elevation: 5, 
  },

})
