import React from "react";
import {View,Text,StyleSheet,TouchableOpacity,StatusBar,LayoutAnimation,ImageBackground} from "react-native";
import { AntDesign } from '@expo/vector-icons';

export default class WalkScreenTwo extends React.Component{

    static navigationOptions = {
        headerShown: false,
    };

    render(){
        LayoutAnimation.easeInEaseOut();
        return(
            <ImageBackground source={require("../assets/bg.jpg")} style={{width:"100%",height:"100%"}}>

            <View style={styles.container}>
                
         {/*Status Bar Light Content Color */}
          <StatusBar barStyle="light-content"></StatusBar>

            {/* Header Image */}
            <View style={{flexDirection:"column",justifyContent:"space-evenly",marginTop:50}}>
              <Text style={styles.greeting}>Welcome<Text style={{color:"#348ceb"}}>!</Text></Text>
              
            </View>
            <Text style={styles.greeting}>Walk2</Text> 

            <TouchableOpacity style={styles.next} onPress={() => this.props.navigation.navigate("Register")} >
                <Text style={{color:"#fff",fontSize:22}}>Next</Text>
              
            </TouchableOpacity>

            </View>

            </ImageBackground>
        );
    };

}

const styles = StyleSheet.create({

    container:{
        flex:1,
        justifyContent:"center",
        alignItems:"center",
    },
    greeting:{
        marginBottom:-10,
        color:"#444",   
        fontSize:60,
        fontWeight:"bold",
        textAlign:"center",   
    },
    next:{
        marginTop:150,
        width:180,
        height:50,
        borderRadius:16,
        backgroundColor:"#348ceb",
        alignItems:"center",
        justifyContent:"center",
        flexDirection:"row",
        justifyContent:"space-around",
        shadowColor: "#404",
        shadowOffset: {
          width: 1000,
            height: 120,
        },
        shadowOpacity:100,
        shadowRadius: 100,
        elevation: 5, 
      },
})