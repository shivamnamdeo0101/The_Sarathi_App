import React from 'react';
import FirebaseKeys from './config';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { Ionicons } from '@expo/vector-icons';

import LoadingScreen from './screens/LoadingScreen';
import LoginScreen from './screens/LoginScreen';
import RegisterScreen from './screens/RegisterScreen';
import HomeScreen from './screens/HomeScreen';
import MessageScreen from './screens/MessageScreen';
import PostScreen from './screens/PostScreen';
import NotificationScreen from './screens/NotificationScreen';
import ProfileScreen from './screens/ProfileScreen';
import WalkScreenOne from './screens/WalkScreenOne';
import WalkScreenTwo from './screens/WalkScreenTwo';
import EditProfileScreen from './screens/EditProfileScreen';
import SchoolFormScreen from './screens/SchoolFormScreen';
import CollegeFormScreen from './screens/CollegeFormScreen';
import PassOutFormScreen from './screens/PassOutFormScreen';
import InterestScreen from './screens/InterestScreen';



const AppContainer = createStackNavigator(

  
  {
    default: createBottomTabNavigator(
      {
        
        Home: {
          screen: HomeScreen,
          navigationOptions: {
            tabBarIcon: ({ tintColor }) => <Ionicons name="ios-home" size={24} color={tintColor} />
          }
        },

        Post: {
          screen: PostScreen,
          navigationOptions: {
            tabBarIcon: ({ tintColor }) =>
              <Ionicons
                name="ios-add-circle"
                size={48}
                color="#aa89fa"
                style={{
                  shadowColor: "#404",
                  shadowOffset: { width: 100, height: 100 },
                  shadowRadius: 10,
                  shadowOpacity: 0.9,
                  shadowRadius: 100,
                  elevation: 14, 
                }} />
          }
        },
       
        Profile: {
          screen: ProfileScreen,
          navigationOptions: {
            tabBarIcon: ({ tintColor }) => <Ionicons name="ios-person" size={24} color={tintColor} />
          }
        },
        
      },
      {
        defaultNavigationOptions: {
          tabBarOnPress: ({ navigation, defaultHandler }) => {
            if (navigation.state.key === "Post") {
              navigation.navigate("postModal")
            } else {
              defaultHandler();
            }
          }
        },
        tabBarOptions: {
          activeTintColor: "#161F3D",
          inactiveTintColor: "#B8BBC4",
          showLabel: false,
          

        },
        
        initialRouteName:"Home"
      },
    ),
    postModal: {
      screen: PostScreen
    },
    Notification: {
      screen: NotificationScreen,
    },
    Message: {
      screen: MessageScreen,
    },
    WalkOne:{
      screen: WalkScreenOne,
    },
    WalkTwo:{
      screen: WalkScreenTwo,
    },
    EditProfile:{
      screen: EditProfileScreen,
    },

    CollegeForm:{
      screen: CollegeFormScreen,
    },
    SchoolForm:{
      screen: SchoolFormScreen,
    },
    PassOutForm:{
      screen: PassOutFormScreen,
    },
    Interest:{
      screen: InterestScreen,
    },


    PassOutFormScreen
 
    
  },
  {
    mode: "modal",
    headerMode: "none",
  }
)

const AuthStack = createStackNavigator(

  {
    Login: LoginScreen,
    Register: RegisterScreen,
    WalkOne:WalkScreenOne,
    WalkTwo:WalkScreenTwo,
   
  },
  {
    initialRouteName:"WalkOne",
    
  }

);

export default createAppContainer(
  createSwitchNavigator(
    {
      Loading: LoadingScreen,
      App: AppContainer,
      Auth: AuthStack,
      
    },
    {
      initialRouteName: "Loading"
    },
  )
);